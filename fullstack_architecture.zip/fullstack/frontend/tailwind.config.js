/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary:   { DEFAULT: '#3B82F6', 50:'#EFF6FF', 100:'#DBEAFE', 500:'#3B82F6', 600:'#2563EB', 700:'#1D4ED8' },
        secondary: { DEFAULT: '#8B5CF6', 500:'#8B5CF6', 600:'#7C3AED' },
        success:   { DEFAULT: '#10B981', 500:'#10B981', 100:'#D1FAE5' },
        warning:   { DEFAULT: '#EAB308', 500:'#EAB308', 100:'#FEF9C3' },
        danger:    { DEFAULT: '#F43F5E', 500:'#F43F5E', 100:'#FFE4E6' },
        surface:   { DEFAULT:'#1E293B', light:'#F8FAFC', dark:'#0F172A' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
