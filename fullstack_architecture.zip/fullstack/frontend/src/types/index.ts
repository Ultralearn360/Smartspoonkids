// ── AUTH ──────────────────────────────────────────
export interface User {
  id:          string
  email:       string
  name:        string
  role:        'ADMIN' | 'USER' | 'MODERATOR'
  avatar?:     string
  isActive:    boolean
  createdAt:   string
  updatedAt:   string
}

export interface AuthState {
  user:            User | null
  accessToken:     string | null
  isAuthenticated: boolean
  isLoading:       boolean
  error:           string | null
}

export interface LoginCredentials {
  email:    string
  password: string
}

export interface RegisterData {
  name:     string
  email:    string
  password: string
}

// ── API RESPONSE ───────────────────────────────────
export interface ApiResponse<T> {
  success: boolean
  data:    T
  message: string
  meta?:   PaginationMeta
}

export interface PaginationMeta {
  page:       number
  limit:      number
  total:      number
  totalPages: number
  hasNext:    boolean
  hasPrev:    boolean
}

export interface ApiError {
  success:  false
  message:  string
  errors?:  ValidationError[]
  code?:    string
}

export interface ValidationError {
  field:   string
  message: string
}

// ── PAGINATION ─────────────────────────────────────
export interface PaginationParams {
  page?:    number
  limit?:   number
  search?:  string
  sortBy?:  string
  order?:   'asc' | 'desc'
}

// ── UI STATE ───────────────────────────────────────
export interface UIState {
  sidebarOpen:  boolean
  theme:        'light' | 'dark'
  isLoading:    boolean
}

// ── DASHBOARD ──────────────────────────────────────
export interface DashboardStats {
  totalUsers:     number
  activeUsers:    number
  totalRevenue:   number
  growthRate:     number
}

export interface ChartDataPoint {
  label: string
  value: number
  date?: string
}
