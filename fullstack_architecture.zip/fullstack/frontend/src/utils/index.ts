import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

// Tailwind class merger
export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs))

// Format currency (INR)
export const formatCurrency = (amount: number, currency = 'INR') =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount)

// Format date
export const formatDate = (date: string | Date, options?: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    ...options,
  }).format(new Date(date))

// Format relative time (e.g. "2 hours ago")
export const formatRelativeTime = (date: string | Date) => {
  const diff = Date.now() - new Date(date).getTime()
  const seconds = Math.floor(diff / 1000)
  if (seconds < 60)   return 'Just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400)return `${Math.floor(seconds / 3600)}h ago`
  return `${Math.floor(seconds / 86400)}d ago`
}

// Truncate text
export const truncate = (str: string, length = 50) =>
  str.length > length ? `${str.slice(0, length)}...` : str

// Get initials from name
export const getInitials = (name: string) =>
  name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)

// Sleep
export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms))

// Debounce
export const debounce = <T extends unknown[]>(fn: (...args: T) => void, delay: number) => {
  let timer: ReturnType<typeof setTimeout>
  return (...args: T) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay) }
}

// Download file
export const downloadFile = (url: string, filename: string) => {
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
}
