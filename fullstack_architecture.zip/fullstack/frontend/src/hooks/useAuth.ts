import { useEffect } from 'react'
import { useAppSelector } from './useAppSelector'
import { useAppDispatch } from './useAppDispatch'
import { fetchMe, logout } from '@store/slices/authSlice'

export function useAuth() {
  const dispatch = useAppDispatch()
  const auth     = useAppSelector(state => state.auth)

  useEffect(() => {
    if (auth.accessToken && !auth.user) {
      dispatch(fetchMe())
    }
  }, [auth.accessToken, auth.user, dispatch])

  return {
    ...auth,
    logout: () => dispatch(logout()),
  }
}
