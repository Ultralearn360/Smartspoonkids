import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link } from 'react-router-dom'
import { Mail, Lock, User } from 'lucide-react'
import { Button } from '@components/ui/Button'
import { Input }  from '@components/ui/Input'
import { useAppDispatch } from '@hooks/useAppDispatch'
import { useAppSelector }  from '@hooks/useAppSelector'
import { register as registerAction } from '@store/slices/authSlice'

const schema = z.object({
  name:            z.string().min(2, 'Name must be at least 2 characters'),
  email:           z.string().email('Invalid email address'),
  password:        z.string().min(8, 'Password must be at least 8 characters')
                             .regex(/[A-Z]/, 'Must contain uppercase letter')
                             .regex(/[0-9]/, 'Must contain a number'),
  confirmPassword: z.string(),
}).refine(d => d.password === d.confirmPassword, {
  message: 'Passwords do not match', path: ['confirmPassword'],
})
type FormData = z.infer<typeof schema>

export default function RegisterPage() {
  const dispatch = useAppDispatch()
  const { isLoading, error } = useAppSelector(s => s.auth)
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })
  const onSubmit = ({ name, email, password }: FormData) =>
    dispatch(registerAction({ name, email, password }))

  return (
    <div className="card animate-slide-up">
      <h2 className="text-xl font-bold text-white mb-1">Create an account</h2>
      <p className="text-slate-400 text-sm mb-6">Start your journey today</p>

      {error && (
        <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-400 text-sm">{error}</div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        <Input label="Full name" placeholder="John Doe" leftIcon={<User size={16} />}
               error={errors.name?.message} {...register('name')} />
        <Input label="Email address" type="email" placeholder="you@example.com"
               leftIcon={<Mail size={16} />} error={errors.email?.message} {...register('email')} />
        <Input label="Password" type="password" placeholder="Min. 8 chars, uppercase + number"
               leftIcon={<Lock size={16} />} error={errors.password?.message} {...register('password')} />
        <Input label="Confirm password" type="password" placeholder="Repeat your password"
               leftIcon={<Lock size={16} />} error={errors.confirmPassword?.message} {...register('confirmPassword')} />

        <Button type="submit" className="w-full" size="lg" isLoading={isLoading}>Create account</Button>
      </form>

      <p className="text-center text-sm text-slate-400 mt-6">
        Already have an account?{' '}
        <Link to="/login" className="text-blue-400 hover:text-blue-300 font-medium">Sign in</Link>
      </p>
    </div>
  )
}
