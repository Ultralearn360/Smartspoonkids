import { Link } from 'react-router-dom'
import { Home, AlertTriangle } from 'lucide-react'
import { Button } from '@components/ui/Button'

export default function NotFoundPage() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="text-center animate-slide-up">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-slate-800 border border-slate-700 rounded-2xl mb-6">
          <AlertTriangle size={36} className="text-yellow-400" />
        </div>
        <h1 className="text-7xl font-bold text-white mb-2">404</h1>
        <p className="text-xl text-slate-400 mb-2">Page not found</p>
        <p className="text-sm text-slate-500 mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Button as={Link} to="/dashboard" leftIcon={<Home size={16} />} size="lg">
          Back to Dashboard
        </Button>
      </div>
    </div>
  )
}
