import { useQuery } from '@tanstack/react-query'
import { Users, TrendingUp, DollarSign, Activity } from 'lucide-react'
import { Card } from '@components/ui/Card'
import { userService } from '@services/userService'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts'

const statCards = [
  { label: 'Total Users',    key: 'totalUsers',   icon: Users,      colour: '#3B82F6', suffix: '' },
  { label: 'Active Users',   key: 'activeUsers',  icon: Activity,   colour: '#10B981', suffix: '' },
  { label: 'Monthly Revenue',key: 'revenue',      icon: DollarSign, colour: '#EAB308', suffix: '₹' },
  { label: 'Growth Rate',    key: 'growthRate',   icon: TrendingUp, colour: '#8B5CF6', suffix: '%' },
]

const lineData = [
  { month: 'Jan', users: 120, revenue: 4200 },
  { month: 'Feb', users: 190, revenue: 5800 },
  { month: 'Mar', users: 250, revenue: 7200 },
  { month: 'Apr', users: 310, revenue: 8900 },
  { month: 'May', users: 420, revenue: 11400 },
  { month: 'Jun', users: 530, revenue: 14200 },
]
const barData = [
  { day: 'Mon', sessions: 48 }, { day: 'Tue', sessions: 72 },
  { day: 'Wed', sessions: 61 }, { day: 'Thu', sessions: 85 },
  { day: 'Fri', sessions: 93 }, { day: 'Sat', sessions: 42 },
  { day: 'Sun', sessions: 29 },
]
const pieData = [
  { name: 'Admin', value: 8, colour: '#3B82F6' },
  { name: 'Users', value: 72, colour: '#10B981' },
  { name: 'Moderators', value: 20, colour: '#8B5CF6' },
]

export default function DashboardPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn:  () => userService.getDashboardStats().then(r => r.data.data),
  })

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="page-title">Dashboard</h1>
        <p className="page-sub">Welcome back — here's what's happening today.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {statCards.map(({ label, key, icon: Icon, colour, suffix }) => (
          <div key={key} className="card relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 rounded-full opacity-10 -translate-y-8 translate-x-8"
                 style={{ background: colour }} />
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-400">{label}</span>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center"
                   style={{ background: `${colour}20` }}>
                <Icon size={18} style={{ color: colour }} />
              </div>
            </div>
            {isLoading ? (
              <div className="h-8 w-24 bg-slate-700 rounded animate-pulse" />
            ) : (
              <p className="text-3xl font-bold text-white">
                {suffix}{(data as Record<string, number> | undefined)?.[key] ?? '—'}
              </p>
            )}
            <p className="text-xs text-emerald-400 mt-1">▲ 12.5% from last month</p>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Line chart */}
        <Card title="User Growth" className="lg:col-span-2"
              description="Monthly registered users vs revenue">
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={lineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="month" tick={{ fill: '#64748B', fontSize: 12 }} />
              <YAxis tick={{ fill: '#64748B', fontSize: 12 }} />
              <Tooltip contentStyle={{ background: '#1E293B', border: '1px solid #334155', borderRadius: 8 }} />
              <Line type="monotone" dataKey="users"   stroke="#3B82F6" strokeWidth={2} dot={false} name="Users" />
              <Line type="monotone" dataKey="revenue" stroke="#10B981" strokeWidth={2} dot={false} name="Revenue (₹)" />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Pie chart */}
        <Card title="User Roles" description="Distribution by role">
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85}
                   dataKey="value" paddingAngle={3}>
                {pieData.map((entry, i) => <Cell key={i} fill={entry.colour} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#1E293B', border: '1px solid #334155', borderRadius: 8 }} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 12, color: '#94A3B8' }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Bar chart */}
      <Card title="Daily Sessions" description="Active sessions this week">
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={barData} barSize={24}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
            <XAxis dataKey="day" tick={{ fill: '#64748B', fontSize: 12 }} />
            <YAxis tick={{ fill: '#64748B', fontSize: 12 }} />
            <Tooltip contentStyle={{ background: '#1E293B', border: '1px solid #334155', borderRadius: 8 }} />
            <Bar dataKey="sessions" fill="#3B82F6" radius={[4, 4, 0, 0]} name="Sessions" />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  )
}
