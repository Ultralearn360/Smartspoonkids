import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Plus, Search, Trash2, Edit, Eye } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Button }     from '@components/ui/Button'
import { Input }      from '@components/ui/Input'
import { Table }      from '@components/ui/Table'
import { Badge }      from '@components/ui/Badge'
import { Pagination } from '@components/ui/Pagination'
import { userService } from '@services/userService'
import { useDebounce } from '@hooks/useDebounce'
import type { User, PaginationParams } from '@types'

export default function UsersPage() {
  const navigate     = useNavigate()
  const queryClient  = useQueryClient()
  const [params, setParams] = useState<PaginationParams>({ page: 1, limit: 10, order: 'desc' })
  const [search, setSearch] = useState('')
  const debouncedSearch = useDebounce(search, 400)

  const { data, isLoading } = useQuery({
    queryKey: ['users', { ...params, search: debouncedSearch }],
    queryFn:  () => userService.getAll({ ...params, search: debouncedSearch }).then(r => r.data),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => userService.delete(id),
    onSuccess:  () => { queryClient.invalidateQueries({ queryKey: ['users'] }); toast.success('User deleted') },
    onError:    () => toast.error('Failed to delete user'),
  })

  const roleColour: Record<string, 'blue' | 'purple' | 'yellow'> = {
    ADMIN: 'blue', MODERATOR: 'purple', USER: 'yellow',
  }

  const columns = [
    {
      key: 'name', header: 'User', sortable: true,
      render: (u: User) => (
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-semibold text-white flex-shrink-0">
            {u.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="font-medium text-white text-sm">{u.name}</p>
            <p className="text-xs text-slate-400">{u.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'role', header: 'Role', sortable: true,
      render: (u: User) => <Badge variant={roleColour[u.role] ?? 'slate'}>{u.role}</Badge>,
    },
    {
      key: 'isActive', header: 'Status', sortable: true,
      render: (u: User) => (
        <Badge variant={u.isActive ? 'green' : 'red'}>{u.isActive ? 'Active' : 'Inactive'}</Badge>
      ),
    },
    {
      key: 'createdAt', header: 'Joined', sortable: true,
      render: (u: User) => <span className="text-slate-400 text-sm">{new Date(u.createdAt).toLocaleDateString()}</span>,
    },
    {
      key: 'actions', header: '',
      render: (u: User) => (
        <div className="flex items-center gap-1 justify-end">
          <Button variant="ghost" size="icon" onClick={e => { e.stopPropagation(); navigate(`/users/${u.id}`) }}>
            <Eye size={15} />
          </Button>
          <Button variant="ghost" size="icon" onClick={e => { e.stopPropagation(); navigate(`/users/${u.id}?edit=1`) }}>
            <Edit size={15} />
          </Button>
          <Button variant="ghost" size="icon" className="hover:text-rose-400"
                  onClick={e => { e.stopPropagation(); if (confirm('Delete user?')) deleteMutation.mutate(u.id) }}>
            <Trash2 size={15} />
          </Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Users</h1>
          <p className="page-sub">{data?.meta?.total ?? 0} total users</p>
        </div>
        <Button leftIcon={<Plus size={16} />}>Add User</Button>
      </div>

      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1">
            <Input
              placeholder="Search users by name or email..."
              leftIcon={<Search size={15} />}
              value={search}
              onChange={e => { setSearch(e.target.value); setParams(p => ({ ...p, page: 1 })) }}
            />
          </div>
        </div>

        <Table
          columns={columns}
          data={data?.data ?? []}
          isLoading={isLoading}
          emptyText="No users found"
          sortBy={params.sortBy}
          order={params.order}
          onSort={key => setParams(p => ({
            ...p, sortBy: key,
            order: p.sortBy === key && p.order === 'asc' ? 'desc' : 'asc',
          }))}
          onRowClick={u => navigate(`/users/${u.id}`)}
        />

        {data?.meta && (
          <Pagination meta={data.meta} onPageChange={page => setParams(p => ({ ...p, page }))} />
        )}
      </div>
    </div>
  )
}
