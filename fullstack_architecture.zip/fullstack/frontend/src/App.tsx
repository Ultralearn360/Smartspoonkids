import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAppSelector } from '@hooks/useAppSelector'
import MainLayout from '@components/layout/MainLayout'
import AuthLayout from '@components/layout/AuthLayout'
import LoginPage from '@pages/auth/LoginPage'
import RegisterPage from '@pages/auth/RegisterPage'
import ForgotPasswordPage from '@pages/auth/ForgotPasswordPage'
import DashboardPage from '@pages/dashboard/DashboardPage'
import UsersPage from '@pages/users/UsersPage'
import UserDetailPage from '@pages/users/UserDetailPage'
import SettingsPage from '@pages/settings/SettingsPage'
import NotFoundPage from '@pages/NotFoundPage'

// Route guard for protected pages
function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAppSelector(state => state.auth)
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public auth routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login"           element={<LoginPage />} />
          <Route path="/register"        element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        </Route>

        {/* Protected app routes */}
        <Route element={<PrivateRoute><MainLayout /></PrivateRoute>}>
          <Route path="/"               element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard"      element={<DashboardPage />} />
          <Route path="/users"          element={<UsersPage />} />
          <Route path="/users/:id"      element={<UserDetailPage />} />
          <Route path="/settings"       element={<SettingsPage />} />
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  )
}
