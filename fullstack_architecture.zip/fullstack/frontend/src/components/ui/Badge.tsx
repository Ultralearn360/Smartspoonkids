import { clsx } from 'clsx'

type BadgeVariant = 'blue' | 'green' | 'yellow' | 'red' | 'purple' | 'slate'

interface BadgeProps {
  variant?:   BadgeVariant
  children:   React.ReactNode
  className?: string
}

const variants: Record<BadgeVariant, string> = {
  blue:   'bg-blue-500/20 text-blue-400 ring-1 ring-blue-500/30',
  green:  'bg-emerald-500/20 text-emerald-400 ring-1 ring-emerald-500/30',
  yellow: 'bg-yellow-500/20 text-yellow-400 ring-1 ring-yellow-500/30',
  red:    'bg-rose-500/20 text-rose-400 ring-1 ring-rose-500/30',
  purple: 'bg-purple-500/20 text-purple-400 ring-1 ring-purple-500/30',
  slate:  'bg-slate-500/20 text-slate-400 ring-1 ring-slate-500/30',
}

export function Badge({ variant = 'slate', children, className }: BadgeProps) {
  return (
    <span className={clsx('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium', variants[variant], className)}>
      {children}
    </span>
  )
}
