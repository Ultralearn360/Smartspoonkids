import { useEffect, useRef } from 'react'
import { X } from 'lucide-react'
import { clsx } from 'clsx'
import { Button } from './Button'

interface ModalProps {
  isOpen:    boolean
  onClose:   () => void
  title?:    string
  size?:     'sm' | 'md' | 'lg' | 'xl' | 'full'
  children:  React.ReactNode
  footer?:   React.ReactNode
  closable?: boolean
}

const sizes = {
  sm:   'max-w-sm',
  md:   'max-w-md',
  lg:   'max-w-lg',
  xl:   'max-w-2xl',
  full: 'max-w-5xl',
}

export function Modal({ isOpen, onClose, title, size = 'md', children, footer, closable = true }: ModalProps) {
  const overlayRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && closable) onClose() }
    if (isOpen) { document.addEventListener('keydown', handleKey); document.body.style.overflow = 'hidden' }
    return () => { document.removeEventListener('keydown', handleKey); document.body.style.overflow = '' }
  }, [isOpen, onClose, closable])

  if (!isOpen) return null

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={e => { if (e.target === overlayRef.current && closable) onClose() }}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" />
      <div className={clsx(
        'relative w-full bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl',
        'animate-slide-up flex flex-col max-h-[90vh]',
        sizes[size]
      )}>
        {title && (
          <div className="flex items-center justify-between p-6 border-b border-slate-700">
            <h2 className="text-lg font-semibold text-white">{title}</h2>
            {closable && (
              <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
                <X size={18} />
              </Button>
            )}
          </div>
        )}
        <div className="flex-1 overflow-y-auto p-6">{children}</div>
        {footer && (
          <div className="p-6 pt-0 border-t border-slate-700 flex justify-end gap-3">{footer}</div>
        )}
      </div>
    </div>
  )
}
