import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from './Button'
import type { PaginationMeta } from '@types'

interface PaginationProps {
  meta:     PaginationMeta
  onPageChange: (page: number) => void
}

export function Pagination({ meta, onPageChange }: PaginationProps) {
  const { page, totalPages, total, limit } = meta
  const start = (page - 1) * limit + 1
  const end   = Math.min(page * limit, total)

  const pages = Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
    if (totalPages <= 5) return i + 1
    if (page <= 3) return i + 1
    if (page >= totalPages - 2) return totalPages - 4 + i
    return page - 2 + i
  })

  return (
    <div className="flex items-center justify-between pt-4 border-t border-slate-700">
      <p className="text-sm text-slate-400">
        Showing <span className="text-white font-medium">{start}–{end}</span> of{' '}
        <span className="text-white font-medium">{total}</span> results
      </p>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" disabled={!meta.hasPrev} onClick={() => onPageChange(page - 1)}>
          <ChevronLeft size={16} />
        </Button>
        {pages.map(p => (
          <button
            key={p}
            onClick={() => onPageChange(p)}
            className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors
              ${p === page ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
          >
            {p}
          </button>
        ))}
        <Button variant="ghost" size="icon" disabled={!meta.hasNext} onClick={() => onPageChange(page + 1)}>
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  )
}
