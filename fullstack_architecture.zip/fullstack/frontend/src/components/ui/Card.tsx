import { clsx } from 'clsx'

interface CardProps {
  title?:        string
  description?:  string
  headerAction?: React.ReactNode
  footer?:       React.ReactNode
  children:      React.ReactNode
  className?:    string
  padding?:      'sm' | 'md' | 'lg' | 'none'
}

const paddings = { none: '', sm: 'p-4', md: 'p-6', lg: 'p-8' }

export function Card({ title, description, headerAction, footer, children, className, padding = 'md' }: CardProps) {
  return (
    <div className={clsx('bg-slate-800 border border-slate-700 rounded-xl shadow-lg', className)}>
      {(title || headerAction) && (
        <div className="flex items-start justify-between p-6 pb-0">
          <div>
            {title       && <h3 className="text-base font-semibold text-white">{title}</h3>}
            {description && <p className="text-sm text-slate-400 mt-0.5">{description}</p>}
          </div>
          {headerAction && <div className="ml-4 flex-shrink-0">{headerAction}</div>}
        </div>
      )}
      <div className={clsx(paddings[padding], (title || headerAction) && padding !== 'none' && 'pt-4')}>
        {children}
      </div>
      {footer && (
        <div className="px-6 py-4 border-t border-slate-700 bg-slate-800/50 rounded-b-xl">
          {footer}
        </div>
      )}
    </div>
  )
}
