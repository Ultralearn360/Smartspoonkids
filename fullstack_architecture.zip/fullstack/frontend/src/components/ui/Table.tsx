import { clsx } from 'clsx'
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react'

interface Column<T> {
  key:       keyof T | string
  header:    string
  render?:   (row: T) => React.ReactNode
  sortable?: boolean
  width?:    string
}

interface TableProps<T> {
  columns:    Column<T>[]
  data:       T[]
  isLoading?: boolean
  emptyText?: string
  sortBy?:    string
  order?:     'asc' | 'desc'
  onSort?:    (key: string) => void
  onRowClick?: (row: T) => void
}

export function Table<T extends { id: string | number }>({
  columns, data, isLoading, emptyText = 'No data found',
  sortBy, order, onSort, onRowClick,
}: TableProps<T>) {
  const SortIcon = ({ col }: { col: Column<T> }) => {
    if (!col.sortable) return null
    const key = String(col.key)
    if (sortBy !== key) return <ChevronsUpDown size={14} className="text-slate-500" />
    return order === 'asc'
      ? <ChevronUp size={14} className="text-blue-400" />
      : <ChevronDown size={14} className="text-blue-400" />
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-700">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-700 bg-slate-800/80">
            {columns.map(col => (
              <th
                key={String(col.key)}
                style={{ width: col.width }}
                className={clsx(
                  'px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider',
                  col.sortable && 'cursor-pointer hover:text-white select-none'
                )}
                onClick={() => col.sortable && onSort?.(String(col.key))}
              >
                <span className="flex items-center gap-1">
                  {col.header} <SortIcon col={col} />
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <tr key={i} className="border-b border-slate-700/50">
                {columns.map((_, j) => (
                  <td key={j} className="px-4 py-3">
                    <div className="h-4 bg-slate-700 rounded animate-pulse" />
                  </td>
                ))}
              </tr>
            ))
          ) : data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-4 py-12 text-center text-slate-400">
                {emptyText}
              </td>
            </tr>
          ) : (
            data.map(row => (
              <tr
                key={row.id}
                className={clsx('table-row', onRowClick && 'cursor-pointer')}
                onClick={() => onRowClick?.(row)}
              >
                {columns.map(col => (
                  <td key={String(col.key)} className="px-4 py-3 text-slate-300">
                    {col.render
                      ? col.render(row)
                      : String((row as Record<string, unknown>)[String(col.key)] ?? '')}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}
