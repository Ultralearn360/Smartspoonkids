import { forwardRef } from 'react'
import { clsx } from 'clsx'
import { Loader2 } from 'lucide-react'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:  'primary' | 'secondary' | 'danger' | 'ghost' | 'outline'
  size?:     'sm' | 'md' | 'lg' | 'icon'
  isLoading?: boolean
  leftIcon?:  React.ReactNode
  rightIcon?: React.ReactNode
}

const variants = {
  primary:   'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500',
  secondary: 'bg-slate-700 text-white hover:bg-slate-600 focus:ring-slate-500',
  danger:    'bg-rose-600 text-white hover:bg-rose-700 focus:ring-rose-500',
  ghost:     'bg-transparent text-slate-400 hover:bg-slate-800 hover:text-white',
  outline:   'border border-slate-600 text-slate-300 hover:bg-slate-700 hover:border-slate-500',
}
const sizes = {
  sm:   'px-3 py-1.5 text-xs rounded-md',
  md:   'px-4 py-2 text-sm rounded-lg',
  lg:   'px-6 py-3 text-base rounded-xl',
  icon: 'p-2 rounded-lg',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', isLoading, leftIcon, rightIcon,
     children, className, disabled, ...props }, ref) => (
    <button
      ref={ref}
      disabled={disabled || isLoading}
      className={clsx(
        'inline-flex items-center justify-center gap-2 font-medium',
        'transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2',
        'focus:ring-offset-slate-900 disabled:opacity-50 disabled:cursor-not-allowed',
        variants[variant], sizes[size], className
      )}
      {...props}
    >
      {isLoading ? <Loader2 size={14} className="animate-spin" /> : leftIcon}
      {children}
      {!isLoading && rightIcon}
    </button>
  )
)
Button.displayName = 'Button'
