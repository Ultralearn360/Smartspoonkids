import { Outlet, Navigate } from 'react-router-dom'
import { useAppSelector } from '@hooks/useAppSelector'

export default function AuthLayout() {
  const { isAuthenticated } = useAppSelector(state => state.auth)
  if (isAuthenticated) return <Navigate to="/dashboard" replace />

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl" />
      </div>
      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-600 rounded-xl mb-4">
            <span className="text-white font-bold text-lg">FS</span>
          </div>
          <h1 className="text-2xl font-bold text-white">FullStack App</h1>
          <p className="text-slate-400 text-sm mt-1">Professional Full-Stack Platform</p>
        </div>
        <Outlet />
      </div>
    </div>
  )
}
