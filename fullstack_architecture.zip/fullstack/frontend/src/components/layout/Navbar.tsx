import { Bell, Search, LogOut, User } from 'lucide-react'
import { useAppSelector } from '@hooks/useAppSelector'
import { useAppDispatch } from '@hooks/useAppDispatch'
import { logout } from '@store/slices/authSlice'
import { Button } from '@components/ui/Button'

export function Navbar() {
  const dispatch = useAppDispatch()
  const { user } = useAppSelector(state => state.auth)

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6 flex-shrink-0">
      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="search"
          placeholder="Search..."
          className="input w-64 pl-9 py-1.5 text-sm"
        />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="relative">
          <Bell size={18} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full" />
        </Button>

        <div className="flex items-center gap-3 pl-3 border-l border-slate-700">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-xs font-semibold text-white">
            {user?.name?.charAt(0).toUpperCase() ?? 'U'}
          </div>
          {user && (
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-white leading-none">{user.name}</p>
              <p className="text-xs text-slate-400 mt-0.5">{user.role}</p>
            </div>
          )}
          <Button variant="ghost" size="icon" onClick={() => dispatch(logout())} title="Logout">
            <LogOut size={16} />
          </Button>
        </div>
      </div>
    </header>
  )
}
