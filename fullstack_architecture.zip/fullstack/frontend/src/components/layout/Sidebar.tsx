import { NavLink } from 'react-router-dom'
import { LayoutDashboard, Users, Settings, ChevronLeft, ChevronRight } from 'lucide-react'
import { useAppSelector } from '@hooks/useAppSelector'
import { useAppDispatch } from '@hooks/useAppDispatch'
import { toggleSidebar } from '@store/slices/uiSlice'

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/users',     icon: Users,           label: 'Users'     },
  { to: '/settings',  icon: Settings,        label: 'Settings'  },
]

export function Sidebar() {
  const dispatch   = useAppDispatch()
  const { sidebarOpen } = useAppSelector(state => state.ui)

  return (
    <aside className={`fixed left-0 top-0 h-full bg-slate-900 border-r border-slate-800
      flex flex-col transition-all duration-300 z-40 ${sidebarOpen ? 'w-64' : 'w-16'}`}>
      {/* Logo */}
      <div className={`flex items-center h-16 px-4 border-b border-slate-800 gap-3 overflow-hidden`}>
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
          <span className="text-white font-bold text-sm">FS</span>
        </div>
        {sidebarOpen && <span className="text-white font-semibold whitespace-nowrap">FullStack App</span>}
      </div>

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-1 overflow-hidden">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            title={!sidebarOpen ? label : undefined}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium
               transition-all duration-200 overflow-hidden
               ${isActive
                 ? 'bg-blue-600 text-white'
                 : 'text-slate-400 hover:text-white hover:bg-slate-800'}`
            }
          >
            <Icon size={18} className="flex-shrink-0" />
            {sidebarOpen && <span className="whitespace-nowrap">{label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Toggle */}
      <div className="p-2 border-t border-slate-800">
        <button
          onClick={() => dispatch(toggleSidebar())}
          className="w-full flex items-center justify-center p-2 rounded-lg
                     text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          {sidebarOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
        </button>
      </div>
    </aside>
  )
}
