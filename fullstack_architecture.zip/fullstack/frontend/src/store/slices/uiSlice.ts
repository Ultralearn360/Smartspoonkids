import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import type { UIState } from '@types'

const initialState: UIState = {
  sidebarOpen: true,
  theme:       (localStorage.getItem('theme') as 'light' | 'dark') ?? 'dark',
  isLoading:   false,
}

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    toggleSidebar(state)              { state.sidebarOpen = !state.sidebarOpen },
    setSidebar(s, a: PayloadAction<boolean>) { s.sidebarOpen = a.payload },
    setTheme(s, a: PayloadAction<'light' | 'dark'>) {
      s.theme = a.payload
      localStorage.setItem('theme', a.payload)
      document.documentElement.classList.toggle('dark', a.payload === 'dark')
    },
    setGlobalLoading(s, a: PayloadAction<boolean>) { s.isLoading = a.payload },
  },
})

export const { toggleSidebar, setSidebar, setTheme, setGlobalLoading } = uiSlice.actions
export default uiSlice.reducer
