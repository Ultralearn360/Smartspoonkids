import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import type { User, PaginationMeta, PaginationParams } from '@types'

interface UserState {
  list:       User[]
  selected:   User | null
  meta:       PaginationMeta | null
  params:     PaginationParams
  isLoading:  boolean
  error:      string | null
}

const initialState: UserState = {
  list:      [],
  selected:  null,
  meta:      null,
  params:    { page: 1, limit: 10, sortBy: 'createdAt', order: 'desc' },
  isLoading: false,
  error:     null,
}

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUsers(s, a: PayloadAction<{ data: User[]; meta: PaginationMeta }>) {
      s.list = a.payload.data; s.meta = a.payload.meta
    },
    setSelected(s, a: PayloadAction<User | null>) { s.selected = a.payload },
    setParams(s, a: PayloadAction<Partial<PaginationParams>>) {
      s.params = { ...s.params, ...a.payload }
    },
    setLoading(s, a: PayloadAction<boolean>) { s.isLoading = a.payload },
    setError(s, a: PayloadAction<string | null>) { s.error = a.payload },
    removeUser(s, a: PayloadAction<string>) {
      s.list = s.list.filter(u => u.id !== a.payload)
    },
  },
})

export const { setUsers, setSelected, setParams, setLoading, setError, removeUser } = userSlice.actions
export default userSlice.reducer
