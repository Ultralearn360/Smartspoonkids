import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { authService } from '@services/authService'
import type { AuthState, LoginCredentials, RegisterData, User } from '@types'

const initialState: AuthState = {
  user:            null,
  accessToken:     localStorage.getItem('accessToken'),
  isAuthenticated: !!localStorage.getItem('accessToken'),
  isLoading:       false,
  error:           null,
}

// ── Async thunks ──
export const login = createAsyncThunk(
  'auth/login',
  async (credentials: LoginCredentials, { rejectWithValue }) => {
    try {
      const res = await authService.login(credentials)
      localStorage.setItem('accessToken', res.data.accessToken)
      return res.data
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })
        ?.response?.data?.message ?? 'Login failed'
      return rejectWithValue(msg)
    }
  }
)

export const register = createAsyncThunk(
  'auth/register',
  async (data: RegisterData, { rejectWithValue }) => {
    try {
      const res = await authService.register(data)
      localStorage.setItem('accessToken', res.data.accessToken)
      return res.data
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })
        ?.response?.data?.message ?? 'Registration failed'
      return rejectWithValue(msg)
    }
  }
)

export const fetchMe = createAsyncThunk('auth/fetchMe', async (_, { rejectWithValue }) => {
  try {
    const res = await authService.me()
    return res.data
  } catch {
    return rejectWithValue('Session expired')
  }
})

// ── Slice ──
const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout(state) {
      state.user            = null
      state.accessToken     = null
      state.isAuthenticated = false
      state.error           = null
      localStorage.removeItem('accessToken')
    },
    setToken(state, action: PayloadAction<string>) {
      state.accessToken     = action.payload
      state.isAuthenticated = true
      localStorage.setItem('accessToken', action.payload)
    },
    clearError(state) { state.error = null },
    updateUser(state, action: PayloadAction<Partial<User>>) {
      if (state.user) state.user = { ...state.user, ...action.payload }
    },
  },
  extraReducers: builder => {
    // login
    builder
      .addCase(login.pending,   s => { s.isLoading = true;  s.error = null })
      .addCase(login.fulfilled, (s, a) => {
        s.isLoading       = false
        s.user            = a.payload.user
        s.accessToken     = a.payload.accessToken
        s.isAuthenticated = true
      })
      .addCase(login.rejected, (s, a) => {
        s.isLoading = false
        s.error     = a.payload as string
      })
    // register
    builder
      .addCase(register.pending,   s => { s.isLoading = true; s.error = null })
      .addCase(register.fulfilled, (s, a) => {
        s.isLoading = false; s.user = a.payload.user
        s.accessToken = a.payload.accessToken; s.isAuthenticated = true
      })
      .addCase(register.rejected, (s, a) => {
        s.isLoading = false; s.error = a.payload as string
      })
    // fetchMe
    builder
      .addCase(fetchMe.fulfilled, (s, a) => { s.user = a.payload })
      .addCase(fetchMe.rejected,  s => {
        s.user = null; s.accessToken = null; s.isAuthenticated = false
        localStorage.removeItem('accessToken')
      })
  },
})

export const { logout, setToken, clearError, updateUser } = authSlice.actions
export default authSlice.reducer
