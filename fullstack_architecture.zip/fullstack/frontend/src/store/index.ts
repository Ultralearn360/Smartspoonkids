import { configureStore } from '@reduxjs/toolkit'
import authReducer from './slices/authSlice'
import uiReducer   from './slices/uiSlice'
import userReducer  from './slices/userSlice'

export const store = configureStore({
  reducer: {
    auth: authReducer,
    ui:   uiReducer,
    user: userReducer,
  },
  middleware: getDefault =>
    getDefault({ serializableCheck: { ignoredActions: ['persist/PERSIST'] } }),
})

export type RootState   = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
