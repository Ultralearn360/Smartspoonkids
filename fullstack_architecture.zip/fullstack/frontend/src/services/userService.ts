import { apiClient } from './apiClient'
import type { ApiResponse, User, PaginationParams } from '@types'

export const userService = {
  getAll:  (params: PaginationParams) =>
    apiClient.get<ApiResponse<User[]>>('/users', { params }),

  getById: (id: string) =>
    apiClient.get<ApiResponse<User>>(`/users/${id}`),

  create:  (data: Partial<User>) =>
    apiClient.post<ApiResponse<User>>('/users', data),

  update:  (id: string, data: Partial<User>) =>
    apiClient.put<ApiResponse<User>>(`/users/${id}`, data),

  delete:  (id: string) =>
    apiClient.delete<ApiResponse<null>>(`/users/${id}`),

  uploadAvatar: (id: string, file: File) => {
    const form = new FormData()
    form.append('avatar', file)
    return apiClient.post<ApiResponse<{ url: string }>>(`/users/${id}/avatar`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },

  getDashboardStats: () =>
    apiClient.get<ApiResponse<{ totalUsers: number; activeUsers: number; growthRate: number }>>('/users/stats'),
}
