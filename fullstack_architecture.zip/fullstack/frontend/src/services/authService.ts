import { apiClient } from './apiClient'
import type { ApiResponse, LoginCredentials, RegisterData, User } from '@types'

interface AuthResponse {
  user:         User
  accessToken:  string
}

export const authService = {
  login:    (data: LoginCredentials)         => apiClient.post<ApiResponse<AuthResponse>>('/auth/login', data),
  register: (data: RegisterData)             => apiClient.post<ApiResponse<AuthResponse>>('/auth/register', data),
  me:       ()                               => apiClient.get<ApiResponse<User>>('/auth/me'),
  logout:   ()                               => apiClient.post('/auth/logout'),
  refresh:  ()                               => apiClient.post<ApiResponse<{ accessToken: string }>>('/auth/refresh'),
  forgotPassword: (email: string)            => apiClient.post('/auth/forgot-password', { email }),
  resetPassword:  (token: string, password: string) =>
                  apiClient.post('/auth/reset-password', { token, password }),
}
