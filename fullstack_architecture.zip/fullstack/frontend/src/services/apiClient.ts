import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios'
import { store } from '@store'
import { setToken, logout } from '@store/slices/authSlice'

const BASE_URL = import.meta.env.VITE_API_URL ?? '/api/v1'

export const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 15_000,
  headers: { 'Content-Type': 'application/json' },
})

// Attach access token to every request
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = store.getState().auth.accessToken
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

let isRefreshing = false
let failedQueue: Array<{ resolve: (t: string) => void; reject: (e: unknown) => void }> = []

const processQueue = (error: unknown, token: string | null) => {
  failedQueue.forEach(p => error ? p.reject(error) : p.resolve(token!))
  failedQueue = []
}

// Handle 401 → refresh token → retry
apiClient.interceptors.response.use(
  res => res,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean }
    if (error.response?.status !== 401 || original._retry) {
      return Promise.reject(error)
    }
    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        failedQueue.push({
          resolve: token => { original.headers.Authorization = `Bearer ${token}`; resolve(apiClient(original)) },
          reject,
        })
      })
    }
    original._retry = true
    isRefreshing    = true
    try {
      const { data } = await axios.post(`${BASE_URL}/auth/refresh`, {}, { withCredentials: true })
      store.dispatch(setToken(data.data.accessToken))
      processQueue(null, data.data.accessToken)
      original.headers.Authorization = `Bearer ${data.data.accessToken}`
      return apiClient(original)
    } catch (err) {
      processQueue(err, null)
      store.dispatch(logout())
      return Promise.reject(err)
    } finally {
      isRefreshing = false
    }
  }
)
