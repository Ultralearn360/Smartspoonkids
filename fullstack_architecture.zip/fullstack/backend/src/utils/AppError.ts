export class AppError extends Error {
  constructor(
    public message: string,
    public statusCode: number = 500,
    public errors?: { field: string; message: string }[],
    public code?: string,
  ) {
    super(message)
    this.name = 'AppError'
    Error.captureStackTrace(this, this.constructor)
  }
}
