import jwt from 'jsonwebtoken'
import { AppError } from './AppError'

interface TokenPayload { userId: string; role: string; iat?: number; exp?: number }

export const generateTokens = (userId: string, role: string) => ({
  accessToken:  jwt.sign({ userId, role }, process.env.JWT_SECRET!,
                  { expiresIn: process.env.JWT_EXPIRES_IN ?? '15m' }),
  refreshToken: jwt.sign({ userId, role }, process.env.JWT_REFRESH_SECRET!,
                  { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '7d' }),
})

export const verifyToken = (token: string, type: 'access' | 'refresh'): TokenPayload => {
  const secret = type === 'access' ? process.env.JWT_SECRET! : process.env.JWT_REFRESH_SECRET!
  try {
    return jwt.verify(token, secret) as TokenPayload
  } catch (err) {
    const msg = (err as Error).name === 'TokenExpiredError' ? 'Token expired' : 'Invalid token'
    throw new AppError(msg, 401)
  }
}
