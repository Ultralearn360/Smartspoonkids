import { Response } from 'express'
import type { PaginationMeta } from '../types'

export class ApiResponse {
  static success<T>(res: Response, data: T, message = 'Success', statusCode = 200) {
    return res.status(statusCode).json({ success: true, data, message })
  }

  static paginated<T>(res: Response, data: T[], meta: PaginationMeta, message = 'Success') {
    return res.status(200).json({ success: true, data, meta, message })
  }

  static error(res: Response, message: string, statusCode = 400) {
    return res.status(statusCode).json({ success: false, message })
  }
}
