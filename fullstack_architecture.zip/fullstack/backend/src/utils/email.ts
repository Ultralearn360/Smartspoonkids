import nodemailer from 'nodemailer'
import { logger } from './logger'

const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST,
  port:   Number(process.env.SMTP_PORT ?? 587),
  secure: false,
  auth:   { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
})

const FROM = `"${process.env.APP_NAME ?? 'App'}" <${process.env.EMAIL_FROM}>`

export const emailUtil = {
  async sendWelcome(to: string, name: string) {
    await transporter.sendMail({
      from: FROM, to,
      subject: 'Welcome! Your account is ready',
      html: `<h2>Hi ${name}!</h2><p>Your account has been created successfully.</p>`,
    })
  },

  async sendPasswordReset(to: string, token: string) {
    const url = `${process.env.CORS_ORIGIN}/reset-password?token=${token}`
    await transporter.sendMail({
      from: FROM, to,
      subject: 'Password Reset Request',
      html: `<h2>Reset your password</h2>
             <p>Click the link below (valid for 1 hour):</p>
             <a href="${url}">${url}</a>`,
    })
  },
}
