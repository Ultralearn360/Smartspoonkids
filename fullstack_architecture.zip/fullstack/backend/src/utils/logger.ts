import winston from 'winston'

const { combine, timestamp, printf, colorize, errors } = winston.format

const devFormat = printf(({ level, message, timestamp, stack }) =>
  `${timestamp} [${level}]: ${stack ?? message}`)

export const logger = winston.createLogger({
  level:  process.env.LOG_LEVEL ?? 'info',
  format: combine(errors({ stack: true }), timestamp({ format: 'HH:mm:ss' })),
  transports: [
    new winston.transports.Console({
      format: combine(colorize(), devFormat),
      silent: process.env.NODE_ENV === 'test',
    }),
    new winston.transports.File({
      filename: 'logs/error.log',   level: 'error',
      format:   combine(timestamp(), winston.format.json()),
    }),
    new winston.transports.File({
      filename: 'logs/combined.log',
      format:   combine(timestamp(), winston.format.json()),
    }),
  ],
})
