import { prisma }     from '../config/database'
import type { PaginationParams } from '../types'

export class UserRepository {
  async findAll({ page, limit, search, sortBy, order }: PaginationParams) {
    const skip  = (page - 1) * limit
    const where = search
      ? { OR: [
            { name:  { contains: search, mode: 'insensitive' as const } },
            { email: { contains: search, mode: 'insensitive' as const } },
          ],
          deletedAt: null,
        }
      : { deletedAt: null }

    const [data, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take:    limit,
        orderBy: { [sortBy]: order },
        select:  this.safeSelect,
      }),
      prisma.user.count({ where }),
    ])

    const totalPages = Math.ceil(total / limit)
    return {
      data,
      meta: {
        page, limit, total, totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
    }
  }

  async findById(id: string) {
    return prisma.user.findFirst({ where: { id, deletedAt: null }, select: this.safeSelect })
  }

  async findByEmail(email: string) {
    return prisma.user.findFirst({ where: { email, deletedAt: null } })
  }

  async create(data: { name: string; email: string; password: string }) {
    return prisma.user.create({ data })
  }

  async update(id: string, data: Record<string, unknown>) {
    return prisma.user.update({ where: { id }, data, select: this.safeSelect })
  }

  async softDelete(id: string) {
    return prisma.user.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } })
  }

  async count(where?: Record<string, unknown>) {
    return prisma.user.count({ where: { ...where, deletedAt: null } })
  }

  private safeSelect = {
    id: true, name: true, email: true, role: true,
    avatar: true, isActive: true, createdAt: true, updatedAt: true,
  }
}
