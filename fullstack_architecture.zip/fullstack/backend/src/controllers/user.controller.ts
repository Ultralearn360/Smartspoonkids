import { Request, Response } from 'express'
import { UserService }  from '../services/user.service'
import { ApiResponse }  from '../utils/ApiResponse'
import { AppError }     from '../utils/AppError'

const userService = new UserService()

export class UserController {
  getAll = async (req: Request, res: Response) => {
    const { page = 1, limit = 10, search, sortBy = 'createdAt', order = 'desc' } = req.query
    const result = await userService.getAll({
      page: Number(page), limit: Number(limit),
      search: String(search ?? ''), sortBy: String(sortBy),
      order: String(order) as 'asc' | 'desc',
    })
    ApiResponse.paginated(res, result.data, result.meta)
  }

  getById = async (req: Request, res: Response) => {
    const user = await userService.getById(req.params.id)
    if (!user) throw new AppError('User not found', 404)
    ApiResponse.success(res, user, 'User fetched')
  }

  update = async (req: Request, res: Response) => {
    const user = await userService.update(req.params.id, req.body)
    ApiResponse.success(res, user, 'User updated')
  }

  delete = async (req: Request, res: Response) => {
    await userService.delete(req.params.id)
    ApiResponse.success(res, null, 'User deleted')
  }

  uploadAvatar = async (req: Request, res: Response) => {
    if (!req.file) throw new AppError('No file uploaded', 400)
    const url = await userService.uploadAvatar(req.params.id, req.file)
    ApiResponse.success(res, { url }, 'Avatar updated')
  }

  getStats = async (_req: Request, res: Response) => {
    const stats = await userService.getStats()
    ApiResponse.success(res, stats, 'Stats fetched')
  }
}
