import { Request, Response } from 'express'
import { AuthService }  from '../services/auth.service'
import { ApiResponse }  from '../utils/ApiResponse'
import { AppError }     from '../utils/AppError'

const authService = new AuthService()

export class AuthController {
  register = async (req: Request, res: Response) => {
    const result = await authService.register(req.body)
    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict', maxAge: 7 * 24 * 60 * 60 * 1000,
    })
    ApiResponse.success(res, { user: result.user, accessToken: result.accessToken },
      'Account created successfully', 201)
  }

  login = async (req: Request, res: Response) => {
    const result = await authService.login(req.body)
    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict', maxAge: 7 * 24 * 60 * 60 * 1000,
    })
    ApiResponse.success(res, { user: result.user, accessToken: result.accessToken }, 'Login successful')
  }

  logout = async (req: Request, res: Response) => {
    await authService.logout(req.user!.id)
    res.clearCookie('refreshToken')
    ApiResponse.success(res, null, 'Logged out successfully')
  }

  refresh = async (req: Request, res: Response) => {
    const token = req.cookies.refreshToken
    if (!token) throw new AppError('No refresh token', 401)
    const result = await authService.refreshToken(token)
    ApiResponse.success(res, { accessToken: result.accessToken }, 'Token refreshed')
  }

  me = async (req: Request, res: Response) => {
    const user = await authService.getMe(req.user!.id)
    ApiResponse.success(res, user, 'User fetched')
  }

  forgotPassword = async (req: Request, res: Response) => {
    await authService.forgotPassword(req.body.email)
    ApiResponse.success(res, null, 'Password reset email sent if account exists')
  }

  resetPassword = async (req: Request, res: Response) => {
    await authService.resetPassword(req.body.token, req.body.password)
    ApiResponse.success(res, null, 'Password reset successfully')
  }
}
