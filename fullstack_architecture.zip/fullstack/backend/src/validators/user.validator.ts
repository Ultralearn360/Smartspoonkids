import { z } from 'zod'

export const updateUserSchema = z.object({
  name:     z.string().min(2).max(80).trim().optional(),
  isActive: z.boolean().optional(),
}).strict()
