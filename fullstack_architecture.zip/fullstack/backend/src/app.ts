import express, { Application, Request, Response, NextFunction } from 'express'
import cors         from 'cors'
import helmet       from 'helmet'
import compression  from 'compression'
import morgan       from 'morgan'
import cookieParser from 'cookie-parser'
import { rateLimit } from 'express-rate-limit'
import { apiRouter }        from './routes'
import { errorHandler }     from './middleware/errorHandler'
import { notFoundHandler }  from './middleware/notFoundHandler'
import { logger }           from './utils/logger'

const app: Application = express()

// ── Security ──
app.use(helmet())
app.use(cors({
  origin:      process.env.CORS_ORIGIN ?? 'http://localhost:3000',
  credentials: true,
  methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}))
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max:      100,
  message:  { success: false, message: 'Too many requests — try again later' },
}))

// ── Body parsing ──
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))
app.use(cookieParser())
app.use(compression())

// ── Logging ──
app.use(morgan('combined', {
  stream: { write: msg => logger.http(msg.trim()) },
  skip: () => process.env.NODE_ENV === 'test',
}))

// ── Health check ──
app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', uptime: process.uptime(), timestamp: new Date().toISOString() })
})

// ── API routes ──
app.use(process.env.API_PREFIX ?? '/api/v1', apiRouter)

// ── Error handling ──
app.use(notFoundHandler)
app.use(errorHandler)

export default app
