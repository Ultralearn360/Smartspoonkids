import Bull from 'bull'
import { logger }    from '../utils/logger'
import { emailUtil } from '../utils/email'

export const emailQueue = new Bull('email', {
  redis: process.env.REDIS_URL ?? 'redis://localhost:6379',
  defaultJobOptions: { attempts: 3, backoff: { type: 'exponential', delay: 5000 } },
})

emailQueue.process('welcome', async job => {
  await emailUtil.sendWelcome(job.data.to, job.data.name)
  logger.info(`Welcome email sent to ${job.data.to}`)
})

emailQueue.process('resetPassword', async job => {
  await emailUtil.sendPasswordReset(job.data.to, job.data.token)
  logger.info(`Reset email sent to ${job.data.to}`)
})

emailQueue.on('failed', (job, err) => {
  logger.error(`Email job ${job.id} failed:`, err.message)
})
