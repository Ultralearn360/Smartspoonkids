import 'express-async-errors'
import 'dotenv/config'
import { createServer } from 'http'
import { Server }        from 'socket.io'
import app               from './app'
import { connectDB }     from './config/database'
import { connectRedis }  from './config/redis'
import { logger }        from './utils/logger'
import { setupSocketIO } from './config/socket'

const PORT = Number(process.env.PORT ?? 5000)

async function bootstrap() {
  await connectDB()
  await connectRedis()

  const httpServer = createServer(app)
  const io = new Server(httpServer, {
    cors: { origin: process.env.CORS_ORIGIN, credentials: true },
  })
  setupSocketIO(io)

  httpServer.listen(PORT, () => {
    logger.info(`Server running on http://localhost:${PORT}`)
    logger.info(`Environment: ${process.env.NODE_ENV}`)
  })

  const shutdown = async (signal: string) => {
    logger.info(`${signal} received — shutting down gracefully`)
    httpServer.close(() => { logger.info('HTTP server closed'); process.exit(0) })
  }
  process.on('SIGTERM', () => shutdown('SIGTERM'))
  process.on('SIGINT',  () => shutdown('SIGINT'))
  process.on('unhandledRejection', (reason) => {
    logger.error('Unhandled Rejection:', reason)
    process.exit(1)
  })
}

bootstrap()
