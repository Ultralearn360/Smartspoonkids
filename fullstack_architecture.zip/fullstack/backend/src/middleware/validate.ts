import { Request, Response, NextFunction } from 'express'
import { ZodSchema, ZodError } from 'zod'
import { AppError } from '../utils/AppError'

export const validate = (schema: ZodSchema) =>
  async (req: Request, _res: Response, next: NextFunction) => {
    try {
      req.body = await schema.parseAsync(req.body)
      next()
    } catch (err) {
      if (err instanceof ZodError) {
        const errors = err.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        throw new AppError('Validation failed', 422, errors)
      }
      next(err)
    }
  }
