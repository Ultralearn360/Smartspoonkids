import { Request, Response, NextFunction } from 'express'
import { verifyToken } from '../utils/jwt'
import { AppError }    from '../utils/AppError'

export const authenticate = (req: Request, _res: Response, next: NextFunction) => {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) throw new AppError('No token provided', 401)

  const token   = header.split(' ')[1]
  const payload = verifyToken(token, 'access')
  req.user      = { id: payload.userId, role: payload.role }
  next()
}
