import multer, { FileFilterCallback } from 'multer'
import { Request }  from 'express'
import { AppError } from '../utils/AppError'

const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
const MAX_SIZE      = 5 * 1024 * 1024 // 5 MB

const fileFilter = (_req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
  if (ALLOWED_TYPES.includes(file.mimetype)) cb(null, true)
  else cb(new AppError('Only JPEG, PNG, WebP files are allowed', 400) as unknown as null, false)
}

export const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: MAX_SIZE, files: 1 },
  fileFilter,
})
