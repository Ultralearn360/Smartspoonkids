import { Request, Response, NextFunction } from 'express'
import { AppError } from '../utils/AppError'
import { logger }   from '../utils/logger'

export const errorHandler = (
  err: Error, req: Request, res: Response, _next: NextFunction
) => {
  if (err instanceof AppError) {
    logger.warn(`[${req.method}] ${req.path} — ${err.statusCode}: ${err.message}`)
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
      errors:  err.errors ?? [],
      code:    err.code,
    })
  }
  logger.error(`[${req.method}] ${req.path} — Unexpected error:`, err)
  res.status(500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  })
}
