import { Request, Response, NextFunction } from 'express'
import { AppError } from '../utils/AppError'

type Role = 'ADMIN' | 'MODERATOR' | 'USER'

export const authorize = (...roles: Role[]) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) throw new AppError('Not authenticated', 401)
    if (!roles.includes(req.user.role as Role))
      throw new AppError('Insufficient permissions', 403)
    next()
  }
