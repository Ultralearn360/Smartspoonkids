export interface PaginationParams {
  page:    number
  limit:   number
  search?: string
  sortBy:  string
  order:   'asc' | 'desc'
}

export interface PaginationMeta {
  page:       number
  limit:      number
  total:      number
  totalPages: number
  hasNext:    boolean
  hasPrev:    boolean
}

// Extend Express Request to include user
declare global {
  namespace Express {
    interface Request {
      user?: { id: string; role: string }
    }
  }
}
