import { Redis } from 'ioredis'
import { logger } from '../utils/logger'

export let redisClient: Redis

export const connectRedis = async () => {
  redisClient = new Redis(process.env.REDIS_URL ?? 'redis://localhost:6379', {
    retryStrategy: times => Math.min(times * 50, 2000),
    lazyConnect:   true,
  })
  await redisClient.connect()
  logger.info('Redis connected')
  redisClient.on('error', err => logger.error('Redis error:', err))
}
