import { PrismaClient } from '@prisma/client'
import { logger }       from '../utils/logger'

export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development'
    ? [{ emit: 'event', level: 'query' }]
    : [],
})

if (process.env.NODE_ENV === 'development') {
  prisma.$on('query' as never, (e: { query: string; duration: number }) => {
    logger.debug(`Query: ${e.query} — ${e.duration}ms`)
  })
}

export const connectDB = async () => {
  await prisma.$connect()
  logger.info('PostgreSQL connected via Prisma')
}
