import { Server, Socket } from 'socket.io'
import { verifyToken }    from '../utils/jwt'
import { logger }         from '../utils/logger'

export const setupSocketIO = (io: Server) => {
  // Auth middleware for Socket.io
  io.use((socket: Socket, next) => {
    try {
      const token = socket.handshake.auth.token
      if (!token) throw new Error('No token')
      const payload = verifyToken(token, 'access')
      socket.data.userId = payload.userId
      socket.data.role   = payload.role
      next()
    } catch {
      next(new Error('Authentication failed'))
    }
  })

  io.on('connection', (socket: Socket) => {
    const userId = socket.data.userId
    logger.info(`Socket connected: ${socket.id} (user: ${userId})`)

    socket.join(`user:${userId}`)

    socket.on('join:room',  (room: string) => socket.join(room))
    socket.on('leave:room', (room: string) => socket.leave(room))

    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.id}`)
    })
  })

  return io
}
