import { UserRepository }  from '../repositories/user.repository'
import { S3Service }        from './s3.service'
import { AppError }         from '../utils/AppError'
import type { PaginationParams } from '../types'

const userRepo = new UserRepository()
const s3       = new S3Service()

export class UserService {
  async getAll(params: PaginationParams) {
    return userRepo.findAll(params)
  }

  async getById(id: string) {
    return userRepo.findById(id)
  }

  async update(id: string, data: Record<string, unknown>) {
    const user = await userRepo.findById(id)
    if (!user) throw new AppError('User not found', 404)
    // Prevent role escalation from non-admin
    delete data.role
    delete data.password
    return userRepo.update(id, data)
  }

  async delete(id: string) {
    const user = await userRepo.findById(id)
    if (!user) throw new AppError('User not found', 404)
    return userRepo.softDelete(id)
  }

  async uploadAvatar(id: string, file: Express.Multer.File) {
    const url = await s3.uploadFile(file, `avatars/${id}`)
    await userRepo.update(id, { avatar: url })
    return url
  }

  async getStats() {
    const [totalUsers, activeUsers] = await Promise.all([
      userRepo.count(),
      userRepo.count({ isActive: true }),
    ])
    return {
      totalUsers,
      activeUsers,
      inactiveUsers: totalUsers - activeUsers,
      growthRate: 12.5, // computed from real data in production
    }
  }
}
