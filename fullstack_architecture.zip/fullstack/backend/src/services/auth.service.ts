import bcrypt from 'bcryptjs'
import { UserRepository } from '../repositories/user.repository'
import { generateTokens, verifyToken } from '../utils/jwt'
import { AppError }   from '../utils/AppError'
import { redisClient } from '../config/redis'
import { emailQueue }  from '../jobs/email.queue'
import crypto          from 'crypto'

const userRepo = new UserRepository()

export class AuthService {
  async register(data: { name: string; email: string; password: string }) {
    const exists = await userRepo.findByEmail(data.email)
    if (exists) throw new AppError('Email already registered', 409)

    const hashedPassword = await bcrypt.hash(data.password, 12)
    const user = await userRepo.create({ ...data, password: hashedPassword })
    const { accessToken, refreshToken } = generateTokens(user.id, user.role)

    await redisClient.set(`refresh:${user.id}`, refreshToken, 'EX', 7 * 24 * 60 * 60)
    await emailQueue.add('welcome', { to: user.email, name: user.name })

    const { password: _, ...safeUser } = user
    return { user: safeUser, accessToken, refreshToken }
  }

  async login(data: { email: string; password: string }) {
    const user = await userRepo.findByEmail(data.email)
    if (!user) throw new AppError('Invalid email or password', 401)
    if (!user.isActive) throw new AppError('Account is deactivated', 403)

    const valid = await bcrypt.compare(data.password, user.password)
    if (!valid) throw new AppError('Invalid email or password', 401)

    const { accessToken, refreshToken } = generateTokens(user.id, user.role)
    await redisClient.set(`refresh:${user.id}`, refreshToken, 'EX', 7 * 24 * 60 * 60)

    const { password: _, ...safeUser } = user
    return { user: safeUser, accessToken, refreshToken }
  }

  async logout(userId: string) {
    await redisClient.del(`refresh:${userId}`)
  }

  async refreshToken(token: string) {
    const payload = verifyToken(token, 'refresh')
    const stored  = await redisClient.get(`refresh:${payload.userId}`)
    if (!stored || stored !== token) throw new AppError('Invalid refresh token', 401)

    const user = await userRepo.findById(payload.userId)
    if (!user || !user.isActive) throw new AppError('User not found', 404)

    const { accessToken, refreshToken: newRefresh } = generateTokens(user.id, user.role)
    await redisClient.set(`refresh:${user.id}`, newRefresh, 'EX', 7 * 24 * 60 * 60)

    return { accessToken }
  }

  async getMe(userId: string) {
    const user = await userRepo.findById(userId)
    if (!user) throw new AppError('User not found', 404)
    const { password: _, ...safeUser } = user
    return safeUser
  }

  async forgotPassword(email: string) {
    const user = await userRepo.findByEmail(email)
    if (!user) return // Silent — don't reveal existence

    const token   = crypto.randomBytes(32).toString('hex')
    const expires = Date.now() + 60 * 60 * 1000 // 1 hour
    await redisClient.set(`reset:${token}`, JSON.stringify({ userId: user.id, expires }), 'EX', 3600)
    await emailQueue.add('resetPassword', { to: user.email, name: user.name, token })
  }

  async resetPassword(token: string, newPassword: string) {
    const stored = await redisClient.get(`reset:${token}`)
    if (!stored) throw new AppError('Invalid or expired reset token', 400)

    const { userId, expires } = JSON.parse(stored)
    if (Date.now() > expires) throw new AppError('Reset token expired', 400)

    const hashed = await bcrypt.hash(newPassword, 12)
    await userRepo.update(userId, { password: hashed })
    await redisClient.del(`reset:${token}`)
  }
}
