import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3'
import { AppError } from '../utils/AppError'
import path          from 'path'
import { v4 as uuid } from 'uuid'

// Note: install uuid → npm i uuid @types/uuid
export class S3Service {
  private s3 = new S3Client({
    region:      process.env.AWS_REGION!,
    credentials: {
      accessKeyId:     process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  })
  private bucket = process.env.AWS_S3_BUCKET!

  async uploadFile(file: Express.Multer.File, prefix = 'uploads'): Promise<string> {
    const ext      = path.extname(file.originalname)
    const key      = `${prefix}/${uuid()}${ext}`
    try {
      await this.s3.send(new PutObjectCommand({
        Bucket:      this.bucket,
        Key:         key,
        Body:        file.buffer,
        ContentType: file.mimetype,
        ACL:         'public-read',
      }))
      return `https://${this.bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`
    } catch (err) {
      throw new AppError(`S3 upload failed: ${(err as Error).message}`, 500)
    }
  }

  async deleteFile(url: string) {
    const key = url.split('.amazonaws.com/')[1]
    await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }))
  }
}
