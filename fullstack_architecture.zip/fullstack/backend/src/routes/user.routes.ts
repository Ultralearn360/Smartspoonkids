import { Router } from 'express'
import { UserController }   from '../controllers/user.controller'
import { authenticate }     from '../middleware/authenticate'
import { authorize }        from '../middleware/authorize'
import { validate }         from '../middleware/validate'
import { upload }           from '../middleware/upload'
import { updateUserSchema } from '../validators/user.validator'

const router = Router()
const ctrl   = new UserController()

// All routes require authentication
router.use(authenticate)

router.get   ('/',           authorize('ADMIN', 'MODERATOR'), ctrl.getAll)
router.get   ('/stats',      authorize('ADMIN'),              ctrl.getStats)
router.get   ('/:id',                                         ctrl.getById)
router.put   ('/:id',        validate(updateUserSchema),      ctrl.update)
router.delete('/:id',        authorize('ADMIN'),              ctrl.delete)
router.post  ('/:id/avatar', upload.single('avatar'),         ctrl.uploadAvatar)

export default router
