import { Router } from 'express'
import { AuthController }   from '../controllers/auth.controller'
import { authenticate }     from '../middleware/authenticate'
import { validate }         from '../middleware/validate'
import { loginSchema, registerSchema, forgotPasswordSchema, resetPasswordSchema }
  from '../validators/auth.validator'

const router = Router()
const ctrl   = new AuthController()

router.post('/register',       validate(registerSchema),       ctrl.register)
router.post('/login',          validate(loginSchema),          ctrl.login)
router.post('/logout',         authenticate,                   ctrl.logout)
router.post('/refresh',                                        ctrl.refresh)
router.get ('/me',             authenticate,                   ctrl.me)
router.post('/forgot-password',validate(forgotPasswordSchema), ctrl.forgotPassword)
router.post('/reset-password', validate(resetPasswordSchema),  ctrl.resetPassword)

export default router
