variable "app_name"         { default = "fullstack" }
variable "environment"      { default = "production" }
variable "aws_region"       { default = "ap-south-1" }
variable "db_instance_class"{ default = "db.t3.micro" }
variable "db_name"          { default = "fullstack_db" }
variable "db_username"      { default = "postgres" }
variable "db_password"      { sensitive = true }
variable "redis_node_type"  { default = "cache.t3.micro" }
