// Run with: ts-node database/seeds/001_seed_users.ts
// Or via:   npx prisma db seed (configured in package.json)

import { PrismaClient } from '@prisma/client'
import bcrypt           from 'bcryptjs'

const prisma = new PrismaClient()

const users = [
  { name: 'Super Admin',  email: 'admin@example.com',     role: 'ADMIN'     as const },
  { name: 'Moderator One',email: 'mod@example.com',       role: 'MODERATOR' as const },
  { name: 'Test User',    email: 'user@example.com',      role: 'USER'      as const },
]

async function main() {
  console.log('🌱 Seeding database...')
  const hashedPassword = await bcrypt.hash('Password123!', 12)

  for (const user of users) {
    const created = await prisma.user.upsert({
      where:  { email: user.email },
      update: {},
      create: { ...user, password: hashedPassword, isActive: true },
    })
    console.log(`✓ ${created.role}: ${created.email}`)
  }

  console.log('✅ Seeding complete')
}

main()
  .catch(e => { console.error('Seed failed:', e); process.exit(1) })
  .finally(async () => await prisma.$disconnect())
