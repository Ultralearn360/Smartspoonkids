-- Migration: 001_initial
-- Created: 2026-05-01
-- Description: Initial schema — users, sessions, audit_logs

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- for full-text search

-- Enum
CREATE TYPE "Role" AS ENUM ('ADMIN', 'MODERATOR', 'USER');

-- Users table
CREATE TABLE "users" (
  "id"         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "name"       VARCHAR(80)  NOT NULL,
  "email"      VARCHAR(255) NOT NULL UNIQUE,
  "password"   VARCHAR(255) NOT NULL,
  "role"       "Role"       NOT NULL DEFAULT 'USER',
  "avatar"     TEXT,
  "isActive"   BOOLEAN      NOT NULL DEFAULT TRUE,
  "deletedAt"  TIMESTAMP,
  "createdAt"  TIMESTAMP    NOT NULL DEFAULT NOW(),
  "updatedAt"  TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email    ON "users"("email");
CREATE INDEX idx_users_role     ON "users"("role");
CREATE INDEX idx_users_isActive ON "users"("isActive");
CREATE INDEX idx_users_name_trgm ON "users" USING gin("name" gin_trgm_ops);

-- Sessions table
CREATE TABLE "sessions" (
  "id"           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId"       UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "refreshToken" TEXT NOT NULL,
  "userAgent"    TEXT,
  "ipAddress"    VARCHAR(45),
  "expiresAt"    TIMESTAMP NOT NULL,
  "createdAt"    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_userId       ON "sessions"("userId");
CREATE INDEX idx_sessions_refreshToken ON "sessions"("refreshToken");

-- Audit logs table
CREATE TABLE "audit_logs" (
  "id"         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId"     UUID NOT NULL REFERENCES "users"("id"),
  "action"     VARCHAR(100) NOT NULL,
  "resource"   VARCHAR(100) NOT NULL,
  "resourceId" UUID,
  "oldValue"   JSONB,
  "newValue"   JSONB,
  "ipAddress"  VARCHAR(45),
  "userAgent"  TEXT,
  "createdAt"  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_userId    ON "audit_logs"("userId");
CREATE INDEX idx_audit_action    ON "audit_logs"("action");
CREATE INDEX idx_audit_createdAt ON "audit_logs"("createdAt");

-- Auto-update updatedAt trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at
  BEFORE UPDATE ON "users"
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
