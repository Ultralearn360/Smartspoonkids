// Shared between Frontend and Backend
export interface ApiResponse<T = unknown> {
  success: boolean
  data:    T
  message: string
  meta?:   PaginationMeta
  errors?: ValidationError[]
}

export interface PaginationMeta {
  page:       number
  limit:      number
  total:      number
  totalPages: number
  hasNext:    boolean
  hasPrev:    boolean
}

export interface ValidationError {
  field:   string
  message: string
}

export interface User {
  id:        string
  name:      string
  email:     string
  role:      'ADMIN' | 'MODERATOR' | 'USER'
  avatar?:   string
  isActive:  boolean
  createdAt: string
  updatedAt: string
}
