export const ROLES = {
  ADMIN:     'ADMIN',
  MODERATOR: 'MODERATOR',
  USER:      'USER',
} as const

export const HTTP_STATUS = {
  OK:                    200,
  CREATED:               201,
  NO_CONTENT:            204,
  BAD_REQUEST:           400,
  UNAUTHORIZED:          401,
  FORBIDDEN:             403,
  NOT_FOUND:             404,
  CONFLICT:              409,
  UNPROCESSABLE_ENTITY:  422,
  TOO_MANY_REQUESTS:     429,
  INTERNAL_SERVER_ERROR: 500,
} as const

export const PAGINATION = {
  DEFAULT_PAGE:  1,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT:     100,
} as const

export const JWT = {
  ACCESS_EXPIRES:  '15m',
  REFRESH_EXPIRES: '7d',
} as const

export const FILE = {
  MAX_SIZE_MB:    5,
  ALLOWED_IMAGES: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
  ALLOWED_DOCS:   ['application/pdf', 'application/msword'],
} as const
